"use client"

import RulesPage from "../rules-page"

export default function SyntheticV0PageForDeployment() {
  return <RulesPage />
}